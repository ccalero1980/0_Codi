typedef struct {
int   n_steps;
int   n_mon;
int   n_cycle;
int   n_fil;/*   Mar */
float mass;
float gamma;
float hydr_radius;
float gamma_head;
float dt;
float k;
float phi_0;
float b_l;
float tolerance;
float amp;
float freq;
float w_length;
int   n_left;
int   n_right;
int   out_freq;
char  infile_name[MAX_BUFF];
char  outfile_name[MAX_BUFF];
char  dir_name[MAX_BUFF];
float amplitude; /* Fab */
float Sperm_Number; /* Fab */
float dist; /*  Mar */
} param_s;


void   configure_sys( int,
                      char    *[],
                      param_s *,
                      vec_s   **,
                      vec_s   **);

void   simulate( param_s,
                 vec_s *,
                 vec_s *  );

/* Bending force routine
Compute bending forces. 
It calls angle_force
Return:   u (???),
          f (forces)
          others?
*/
float  bending_forces( vec_s *,
                       float *,
                       vec_s *,
                       param_s  );
/**************************
Computes angular forces,
diedral????
The forces are combinations of distances......????
*/
float  angle_force( vec_s,
                    vec_s,
                    float,
                    float,
                    float,
                    float,
                    vec_s * );

void    constrain_positions(  vec_s *,
                              vec_s *,
                              vec_s *,
                              param_s );

void   constrain_velocities(  vec_s *, 
                              float *,
                              vec_s *,
                              param_s );

void   constrain_forces(      vec_s *, 
                              float *,
                              vec_s *,
                              param_s );

float   verlet_pt1( vec_s *,
                    vec_s *,
                    vec_s *,
                    vec_s *,
                    param_s );



void   verlet_pt2( vec_s *,
                   vec_s *,
                   vec_s *,
                   vec_s *,
                   param_s );

void oseen( vec_s *,
	    vec_s *,
	    vec_s *,
	    param_s);



void  output_data( vec_s *,
                   vec_s *,
                   vec_s *,
                   param_s,
                   int,
                   float *,
                   float *);


float  boundary_conditions( vec_s *,
                            vec_s *,
                            vec_s *,
                            vec_s *,
                            param_s,
                            int,
                            int        );

/* Fab */
void print_force(vec_s *, param_s, int, char *);
