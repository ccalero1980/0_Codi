#include <stdio.h>
#include <math.h>
#include <stdlib.h>
/* #include <ran.h>*/
#include "useful.h"
#include "os3many.h"
#include "nr.h"
#include "nrutil.h"
#include "nrutil.c"
#include "tridag.c"


#define SMALL_ANGLE 1.0e-10
#define ANG_CONV 57.29578


static vec_s *fc_1, *fc_2, *fc_3, *v_sv, *f_sv;
static vec_s *f_bend, *fc_1a, *fc_2a,*fc_3a;




int main( int argc, char *argv[] )
{
    vec_s *r, *v;

    param_s parameters;
    configure_sys( argc, argv, &parameters, &r, &v);
    simulate( parameters, r, v );

    return(1);
}

/* ######################################################################### */
void  configure_sys( int      argc,
                     char    *argv[],
                     param_s *parameters,
                     vec_s  **r,
                     vec_s  **v  )
/* ######################################################################### */
{
    FILE  *param_file, *info_file, *config_file;

    char   buffer[MAX_BUFF], file_name[MAX_BUFF], dir_name[MAX_BUFF];
    float  sp_numb4;
    int    n_mon,n_fil,i;
    float  rijx, rijy, rijz;

    seed = -789219;

    if( argc == 1 )
    {
              printf("\nNo parameter file name\n" );
       exit( 1 );
    }
    param_file = fopen( argv[1], "r" );
    if( param_file == NULL )
    {
         printf("\nParameter file not found\n");
         exit( 1 );
    }
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%s", file_name );
    config_file = fopen( file_name, "r" );
    if( config_file == NULL )
    {
         printf("\nConfiguration file %s not found\n", file_name );
         fflush( stdout );
         exit( 1 );
    }

    sprintf( parameters->outfile_name,"%s%s", file_name, "_new" );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%s", dir_name );
    sprintf( file_name,"%s%s", dir_name, "info");
    sprintf( parameters->dir_name,"%s", dir_name );
    info_file = fopen( file_name, "w" );
    if( info_file == NULL )
    {
         printf("\nCannot access directory for output %s\n", file_name );
         fflush( stdout );
         exit( 1 );
    }
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%d", &(parameters->n_steps) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%le", &(parameters->dt) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%le", &(parameters->k) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%le", &(parameters->mass) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%le", &(parameters->gamma) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%le", &(parameters->hydr_radius) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%le", &(parameters->gamma_head) );
    fgets( buffer, MAX_BUFF, param_file );

    sscanf( buffer, "%le", &(parameters->phi_0) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%le", &(parameters->tolerance) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%le", &(parameters->amp) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%d", &(parameters->n_cycle) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%le", &(parameters->w_length) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%d", &(parameters->n_left) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%d", &(parameters->n_right) );

    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%d", &(parameters->out_freq) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%le", &(parameters->amplitude) );
    fgets( buffer, MAX_BUFF, param_file );
    sscanf( buffer, "%le", &(parameters->dist) );

    
    /* FM: Sperm Number computation. N.B. L=1 ! */
    sp_numb4 = 2*PI*(parameters->gamma)/(parameters->k);
    sp_numb4 /= ((parameters->n_cycle)*(parameters->dt));
    parameters->Sperm_Number = pow(sp_numb4, 0.25);
    
    

    n_mon = 0;
    n_fil = 2;
    parameters->n_fil = n_fil;
  
    while( fgets( buffer, MAX_BUFF, config_file ) != NULL )
    {
         n_mon++;
    }
   
    rewind(config_file);

    fflush( stdout );
    
    /*   posiz, velocita' di tutti i bead */  

    (*r) = (vec_s *)malloc(  n_mon*n_fil*sizeof( vec_s ));
    (*v) = (vec_s *)malloc(  n_mon*n_fil*sizeof( vec_s ));
       
    for(i=0;i<n_mon;i++){     
      fgets(  buffer, MAX_BUFF, config_file );
      sscanf( buffer,"%le%le%le%le%le%le", &((*r)[i].x),
                                              &((*r)[i].y),
                                              &((*r)[i].z),
                                              &((*v)[i].x),
                                              &((*v)[i].y),
                                              &((*v)[i].z)    );    
	

    }
    fclose( config_file );

    
    // printf("n_mon %d, n_fil %d\n",n_mon, n_fil);

    rijx = (*r)[0].x - (*r)[1].x;
    rijy = (*r)[0].y - (*r)[1].y;
    rijz = (*r)[0].z - (*r)[1].z;
    parameters->b_l         = sqrt(rijx*rijx + rijy*rijy + rijz*rijz );
    parameters->n_mon       = n_mon;
    parameters->mass       /= (float)n_mon;
#ifdef HEAD
    parameters->amplitude /= parameters->mass;
#endif
    parameters->gamma      /= parameters->mass*n_mon;
    parameters->gamma_head /= parameters->mass;
    parameters->amp        *= parameters->k;
    parameters->amp        /= parameters->mass;
    parameters->amp        /= parameters->b_l*parameters->b_l;
    parameters->k          /= parameters->b_l*parameters->b_l;
    parameters->k          /= (float)(n_mon - 2) ;
    parameters->freq        = 2.0*PI/(float)parameters->n_cycle;
    parameters->freq       /= parameters->dt;


  
/* Forze  a = di tutti  */    

    f_bend   = (vec_s *)malloc( parameters->n_mon*sizeof( vec_s ));

    fc_1a    = (vec_s *)malloc( n_mon*n_fil*sizeof( vec_s ));  
    fc_1     = (vec_s *)malloc( n_mon*sizeof( vec_s ));

    fc_2a    = (vec_s *)malloc( n_mon*n_fil*sizeof( vec_s ));
    fc_2     = (vec_s *)malloc( n_mon*sizeof( vec_s ));
 
    fc_3a    = (vec_s *)malloc( n_mon*n_fil*sizeof( vec_s ));
    fc_3     = (vec_s *)malloc( n_mon*sizeof( vec_s ));

    v_sv     = (vec_s *)malloc( n_mon*n_fil*sizeof( vec_s ));
    f_sv     = (vec_s *)malloc( n_mon*n_fil*sizeof( vec_s ));

        
    fprintf( info_file, "Number of steps   = %d\n", parameters->n_steps  );
    fprintf( info_file, "Time-step         = %e\n", parameters->dt       );
    fprintf( info_file, "Bending modulus   = %e\n", parameters->k        );
    fprintf( info_file, "Equilibrium angle = %e\n", parameters->phi_0    ); 
    fprintf( info_file, "Bond length       = %e\n", parameters->b_l      );
    fprintf( info_file, "Tolerance         = %e\n", parameters->tolerance); 
    fprintf( info_file, "hydr radius       = %e\n", 
	     parameters->hydr_radius *parameters->b_l ); 
    fprintf( info_file, "Friction gamma    = %e\n", parameters->gamma    );
    fprintf( info_file, "Frequency         = %e\n", parameters->freq     );
    fprintf( info_file, "Peak torque       = %e\n", parameters->amp      ); 
    fprintf( info_file, "Sperm Number gamma= %e\n", parameters->Sperm_Number); 
    fclose(info_file);
}

/* ########################################################################## */

void  simulate(     param_s  params,
                     vec_s  *r,
                     vec_s  *v)
/* ########################################################################## */
{
    int    i, j, k, l,m, n_mon, step, n_ang, n_fil;

    float  *mags, *mags1;
    float  fx_tot, fy_tot, fz_tot, u, ke;
    float  rijx, rijy, rijz;
    float  work, fpar_ave, fper_ave;
    float  x_start, y_start, cycle_time, ang_tot;
    vec_s *rij, *rij1, *f,*fa, *tang,*v1, *r1, *rm, *rcm;

    FILE *conf = fopen("conf", "w");

    /* Fab */ float freq, amplitude;

    /* Fab */ float fm_work, TOT_fm_work, AV_TOT_fm_work;
    /* Fab */ float ref_work, TOT_ref_work, AV_TOT_ref_work;
    /* Fab */ float velocity, TOT_velocity, AV_TOT_velocity, velocityx, velocityz, velx, velz;
    /* Fab */ int   count, TOT_count;
    /* Fab */ float Ext_force;
    /* Fab */ float Sperm_Number;
    /* Fab */ float x_old, y_old, z_old;
    /* Fab */ char filename[100];
    /* Fab */ FILE *file_ptr;

    /* MCL */ float  loc_dr, fatt, fatt2, b_l , y_amp,y_ampM,y_ampm;
    /* MCL */ float  dr0x, dr0y,drijx,drijy;
    /* MCL */ float dist;

    /* Fab */ vec_s constant_force;
    /* Fab */ constant_force.x = 0.0;
    /* Fab */ constant_force.y = 0.0;
    /* Fab */ constant_force.z = 0.0;

#ifdef LONG
    constant_force.x = 1.0e4;
#endif
#ifdef TRANS
    constant_force.y = 1.0e4;
#endif


    /* Fab */ freq = params.freq;
    /* Fab */ Sperm_Number = params.Sperm_Number;
    /* Fab */ amplitude = params.amplitude;
    /* Fab */ y_ampM = 0;
    /* Fab */ y_ampm = 0;
    /* Fab */ y_amp = 0;

    // printf("AMPLITUDE = %f\n",amplitude);
    // printf("cycle vx             vy              work       ref_work\n");    
    
    dist  = params.dist;
    n_fil = params.n_fil;
    n_mon = params.n_mon;   

    rij   = (vec_s *)malloc((n_mon + 1)*n_fil*sizeof( vec_s ));
    rij1  = (vec_s *)malloc((n_mon + 1)*sizeof( vec_s ));

    fa    = (vec_s *)malloc(n_mon*n_fil*sizeof( vec_s ));
    f     = (vec_s *)malloc(n_mon*sizeof( vec_s ));

    v1    = (vec_s *)malloc(n_mon*sizeof( vec_s ));
    r1    = (vec_s *)malloc(n_mon*sizeof( vec_s ));

    mags  = (float *)malloc(n_mon*n_fil*sizeof( float ));
    mags1 = (float *)malloc(n_mon*sizeof( float ));
    tang  = (vec_s *)malloc(n_mon*sizeof( vec_s ));
  
    rm    = (vec_s *)malloc(n_mon*sizeof( vec_s ));
    rcm = (vec_s *)malloc(n_fil*sizeof( vec_s ));


    /*  generates config  n_fil filaments */
    for(i=0; i<n_fil; i++){
      for(j=0; j<n_mon; j++){
	r[i*n_mon+j].x = r[j].x;
	r[i*n_mon+j].y = r[j].y;
	r[i*n_mon+j].z = r[j].z + i* dist;
	v[i*n_mon+j].x = v[j].x;
	v[i*n_mon+j].y = v[j].y;
	v[i*n_mon+j].z = v[j].z;
      }
    }

    
    
    cycle_time  = params.n_cycle*params.dt;

    for( i = 1; i < n_mon*n_fil; i++ )
    {
       rijx     = r[i-1].x - r[i].x;
       rijy     = r[i-1].y - r[i].y;
       rijz     = r[i-1].z - r[i].z;
       if(i%n_mon==0){
	 rijx     = 0;
	 rijy     = 0;
	 rijz     = 0;  
	 } 
     
       mags[i]  = sqrt(rijx*rijx + rijy*rijy + rijz*rijz);
       rij[i].x = rijx;
       rij[i].y = rijy;
       rij[i].z = rijz;
    }


    //tang solo del primo
        tang[0].x       = -rij[1].x/mags[1];
	tang[0].y       = -rij[1].y/mags[1];
	tang[0].z       = -rij[1].z/mags[1];
	tang[n_mon-1].x = -rij[n_mon-1].x/mags[n_mon-1];
	tang[n_mon-1].y = -rij[n_mon-1].y/mags[n_mon-1];
	tang[n_mon-1].z = -rij[n_mon-1].z/mags[n_mon-1];
	for( i = 1; i < n_mon - 1; i++ )
          {
	    tang[i].x = -0.5*(rij[i].x/mags[i] + rij[i+1].x/mags[i+1]);
	    tang[i].y = -0.5*(rij[i].y/mags[i] + rij[i+1].y/mags[i+1]);
	    tang[i].z = -0.5*(rij[i].z/mags[i] + rij[i+1].z/mags[i+1]);
          }
    //endtang



    for( i = 0; i < n_mon*n_fil; i++ )
    {
       fa[i].x = 0.0;
       fa[i].y = 0.0;
       fa[i].z = 0.0;

       fc_1a[i].x = 0.0;
       fc_1a[i].y = 0.0;
       fc_1a[i].z = 0.0;
       fc_2a[i].x = 0.0;
       fc_2a[i].y = 0.0;
       fc_2a[i].z = 0.0;
       fc_3a[i].x = 0.0;
       fc_3a[i].y = 0.0;
       fc_3a[i].z = 0.0;
    }

    for(m=0; m<n_fil; m++){
      for( i = 0; i < n_mon; i++ ){
	rij1[i].x = rij[i+m*n_mon].x;
	rij1[i].y = rij[i+m*n_mon].y;
	rij1[i].z = rij[i+m*n_mon].z;


	mags1[i] = mags[i+m*n_mon];
	
	f[i].x = fa[i+m*n_mon].x;
	f[i].y = fa[i+m*n_mon].y;
	f[i].z = fa[i+m*n_mon].z;
      }
	
      u    = bending_forces( rij1, mags1, f, params );
     
      for( i = 0; i < n_mon; i++ ){
	fa[i+m*n_mon].x = f[i].x;
	fa[i+m*n_mon].y = f[i].y;
	fa[i+m*n_mon].z = f[i].z;
	
      }
    }

#ifdef CONSTANT_FORCE
    /* Fab */
    /* Add a constant Force all over the flagella */
    /* */for( i = 0; i < n_mon; i++ )
    /* */{
    /* */   fa[i].x += constant_force.x;
    /* */   fa[i].y += constant_force.y;
    /* */   fa[i].z += constant_force.z;
    /* */ }  
    /* end Fab */
#endif
   
#ifdef HEAD
    /* Fab */
    /* Add an oscillating force on the head */
    /* There is a "k" which here is = 0 (is the time....)*/
    /* */   fa[0].y += amplitude*cos(freq*0.0*params.dt);
    /* */   fa[n_mon].y += amplitude*cos(freq*0.0*params.dt);
    /* end Fab */
#endif


#ifdef TORQUE_M
	     fatt       =  amplitude*sin(freq*0.0*params.dt);     
	  
	     
	     dr0x       =   (r[1].x + r[0].x)/2.0;
	     dr0y       =   (r[1].y + r[0].y)/2.0;
	     drijx      =  -(r[0].x - dr0x);
	     drijy      =  +(r[0].y - dr0y);
	     
	     fa[0].x += drijy*fatt;
	     fa[0].y += drijx*fatt;
	     drijx      =  -(r[1].x - dr0x);
	     drijy      =  +(r[1].y - dr0y);
	     fa[1].x   += drijy*fatt;
	     fa[1].y   += drijx*fatt;
#endif

	     /* Fab */
	     TOT_ref_work = 0.0;
	     TOT_fm_work  = 0.0;
	     TOT_velocity = 0.0;
	     TOT_count    = 0;
	     
 

	     /*  inizio ciclo temporale */

////////////////////////////////////////////////////////////////////////////////////////////
//COMEN�A EL CICLE TEMPORAL!!!!!!!!!!!!!!!
////////////////////////////////////////////////////////////////////////////////////////////

   for( j = 0; j < params.n_steps; j++ )
    {
       x_start  = r[n_mon-1].x;
       y_start  = r[n_mon-1].y;
       work     = 0.0;
       n_ang    = 0;
       ang_tot  = 0.0;       
     
       /* Fab */
       fm_work  = 0.0;
       velocity = 0.0;
       velocityx = 0.0;
       velocityz = 0.0;
       count    = 0;

       for( i = 0; i < n_mon; i++ ){
	  rm[i].x=0.0;
	  rm[i].y=0.0;
	  rm[i].z=0.0;}
      
    for( i = 0; i < n_fil; i++ ){
	  rcm[i].x=0.0;
	  rcm[i].y=0.0;
	  rcm[i].z=0.0;}

    for( k = 0; k < params.n_cycle; k++ )
	 {
	   
	   /* FM: to compute the movement at each time step */
	   x_old = r[0].x;
	   y_old = r[0].y;
	   z_old = r[0].z;
    

          step = j*params.n_cycle + k;
          fflush( stdout );

	  for(m=0; m<n_fil; m++){
	    for( i = 0; i < n_mon; i++ ){
	      rij1[i].x = rij[i+m*n_mon].x;
	      rij1[i].y = rij[i+m*n_mon].y;
	      rij1[i].z = rij[i+m*n_mon].z;
	 
	   
	      mags1[i] = mags[i+m*n_mon];
	    
	      v1[i].x = v[i+m*n_mon].x;
	      v1[i].y = v[i+m*n_mon].y;
	      v1[i].z = v[i+m*n_mon].z;
	
	    }
	     

	   
	     constrain_velocities( rij1, mags1, v1, params );
	
	    for( i = 0; i < n_mon; i++ ){
	      v[i+m*n_mon].x = v1[i].x;
	      v[i+m*n_mon].y = v1[i].y;
	      v[i+m*n_mon].z = v1[i].z;
	     
	

	      fc_1a[i+m*n_mon].x   = fc_1[i].x;
	      fc_1a[i+m*n_mon].y   = fc_1[i].y;
	      fc_1a[i+m*n_mon].z   = fc_1[i].z;

	    }
	  }
	   
	
          for( i = 0; i < n_mon*n_fil; i++ )
          {
              v_sv[i].x = v[i].x;
              v_sv[i].y = v[i].y;
              v_sv[i].z = v[i].z;
          }       

          ke = verlet_pt1( r, v, fa, tang, params );


	
	  for(m=0; m<n_fil; m++){
	    for( i = 0; i < n_mon; i++ ){
	      rij1[i].x = rij[i+m*n_mon].x;
	      rij1[i].y = rij[i+m*n_mon].y;
	      rij1[i].z = rij[i+m*n_mon].z;
	      
	      mags1[i] = mags[i+m*n_mon];

	      v1[i].x = v[i+m*n_mon].x;
	      v1[i].y = v[i+m*n_mon].y;
	      v1[i].z = v[i+m*n_mon].z;

	
	      r1[i].x = r[i+m*n_mon].x;
	      r1[i].y = r[i+m*n_mon].y;
	      r1[i].z = r[i+m*n_mon].z;
	
	    }    
	    constrain_positions( r1, rij1, v1, params );
	    
	    for( i = 0; i < n_mon; i++ ){
	      
	    v[i+m*n_mon].x = v1[i].x;
	    v[i+m*n_mon].y = v1[i].y;
	    v[i+m*n_mon].z = v1[i].z;
	    
	   
	    r[i+m*n_mon].x = r1[i].x;
	    r[i+m*n_mon].y = r1[i].y;
	    r[i+m*n_mon].z = r1[i].z;


	

	    fc_2a[i+m*n_mon].x   = fc_2[i].x;
	    fc_2a[i+m*n_mon].y   = fc_2[i].y;
	    fc_2a[i+m*n_mon].z   = fc_2[i].z;
	    }
	  }

	   
	  /*	  if( step % params.out_freq == 0 )
	    {
              output_data( r, v, fa, params, step, &fper_ave, &fpar_ave );
              fflush( stdout );
	    }
	  */

	  for( i = 1; i < n_mon*n_fil; i++ )
	    {
	      rijx     = r[i-1].x - r[i].x;
	      rijy     = r[i-1].y - r[i].y;
	      rijz     = r[i-1].z - r[i].z;
	      if(i%n_mon==0){
		rijx     = 0;
		rijy     = 0;
		rijz     = 0;
	      }
	      mags[i]  = sqrt(rijx*rijx + rijy*rijy + rijz*rijz);
	      rij[i].x = rijx;
	      rij[i].y = rijy;
	      rij[i].z = rijz;
	    }


	

	  //tamg boh
          tang[0].x       = -rij[1].x/mags[1];
          tang[0].y       = -rij[1].y/mags[1];
          tang[0].z       = -rij[1].z/mags[1];
          tang[n_mon-1].x = -rij[n_mon-1].x/mags[n_mon-1];
          tang[n_mon-1].y = -rij[n_mon-1].y/mags[n_mon-1];
          tang[n_mon-1].z = -rij[n_mon-1].z/mags[n_mon-1];
          for( i = 1; i < n_mon - 1; i++ )
          {
             tang[i].x = -0.5*(rij[i].x/mags[i] + rij[i+1].x/mags[i+1]);
             tang[i].y = -0.5*(rij[i].y/mags[i] + rij[i+1].y/mags[i+1]);
             tang[i].z = -0.5*(rij[i].z/mags[i] + rij[i+1].z/mags[i+1]);
          }
	  //tang boh

          for( i = 0; i < n_mon*n_fil; i++ )
          {
	
	    fa[i].x = 0.0;
	    fa[i].y = 0.0;
	    fa[i].z = 0.0;
	  }

	 
	  
#ifdef HEAD
	  /* Fab */
	  /* Add an oscillating force on the head */
          if(y_ampm > r[0].y) y_ampm = r[0].y;
	  if(y_ampM < r[0].y) y_ampM = r[0].y;
//	  printf("%f %f \n", y_ampm,y_ampM); 

	  Ext_force = amplitude*cos(freq*k*params.dt);
	  fa[0].y += Ext_force;
	  fa[n_mon].y += Ext_force;
	  //   f[0].y += (Ext_force=amplitude*cos(freq*k*params.dt)); 
	  /* end Fab */
#endif  

#ifdef CONSTANT_FORCE
          /* Fab */
          /* Add a constant Force all over the flagella */
	  /*  for( i = 0; i < n_mon*n_fil; i++ ) */
          for( i = 0; i < n_mon; i++ )
          {
             fa[i].x += constant_force.x;
             fa[i].y += constant_force.y;
             fa[i].z += constant_force.z;
#endif


	  //questi sono da trasf in pot armonici (trap)
	  
#ifdef TORQUE_M
	     fatt       =  amplitude*sin(freq*k*params.dt);     
	  
	     
	     dr0x       =   (r[1].x + r[0].x)/2.0;
	     dr0y       =   (r[1].y + r[0].y)/2.0;
	     drijx      =  -(r[0].x - dr0x);
	     drijy      =  +(r[0].y - dr0y);
	     
	     fa[0].x += drijy*fatt;
	     fa[0].y += drijx*fatt;
	     drijx      =  -(r[1].x - dr0x);
	     drijy      =  +(r[1].y - dr0y);
	     fa[1].x   += drijy*fatt;
	     fa[1].y   += drijx*fatt;
#endif




#ifdef TORQUE_PINNED
	     b_l = params.b_l;
	     fatt       =  amplitude*sin(freq*k*params.dt);     
	     fatt2      =  amplitude*freq*cos(freq*k*params.dt);
	
	     
	     r[0].y   = 0;
	     v[0].y   = 0;
	     
       	     
	     r[1].y   = b_l*fatt;
	     v[1].y   = b_l*fatt2;	     
#endif

#ifdef TORQUE_PINNED_FIX
	     b_l = params.b_l;
	     fatt       =  amplitude*sin(freq*k*params.dt);     
	     fatt2      =  amplitude*freq*cos(freq*k*params.dt);
	
	     
	     r[0].x   = 0;
	     r[0].y   = 0;
	     v[0].x   = 0;
	     v[0].y   = 0;
	     
       	     r[1].x   = b_l - b_l*fatt;
	     r[1].y   = b_l*fatt;
	     v[1].x   = b_l*fatt2;
	     v[1].y   = - b_l*fatt2;
	     

#endif

	   

	     work += boundary_conditions( r, v, fa, tang, params, step, j);

#ifdef WAVE          
          if(y_ampM < r[0].y) y_ampM = fabs(r[0].y);

	  y_ampm = -y_ampM;
	 
#endif 
	  
	  for(m=0; m<n_fil; m++){
	    for( i = 0; i < n_mon; i++ ){

	      
	      f_bend[i].x = 0.0;
	      f_bend[i].y = 0.0;
	      f_bend[i].z = 0.0;
	

	      rij1[i].x = rij[i+m*n_mon].x;
	      rij1[i].y = rij[i+m*n_mon].y;
	      rij1[i].z = rij[i+m*n_mon].z;


	      mags1[i] = mags[i+m*n_mon];

	
	    }
     
	    u  = bending_forces( rij1, mags1, f_bend, params );
     

	    for( i = 0; i < n_mon; i++ ){
	      fa[i+m*n_mon].x += f_bend[i].x;
	      fa[i+m*n_mon].y += f_bend[i].y;
	      fa[i+m*n_mon].z += f_bend[i].z;	
      
	    }
	  }
	 
/*    for( i = 0; i < n_mon*n_fil; i++ ) */
/*            { */
/*                f_sv[i].x = fa[i].x; */
/*                f_sv[i].y = fa[i].y; */
/*                f_sv[i].z = fa[i].z; */
/*     	      } */

	  for(m=0; m<n_fil; m++){
	    for( i = 0; i < n_mon; i++ ){
	      rij1[i].x = rij[i+m*n_mon].x;
	      rij1[i].y = rij[i+m*n_mon].y;
	      rij1[i].z = rij[i+m*n_mon].z;
	 
	   
	      mags1[i] = mags[i+m*n_mon];
	    
	      f[i].x = fa[i+m*n_mon].x;
	      f[i].y = fa[i+m*n_mon].y;
	      f[i].z = fa[i+m*n_mon].z;
	
	    }
	     

	   
	      constrain_forces(rij1, mags1, f, params );
	
	    for( i = 0; i < n_mon; i++ ){
	      fc_3a[i+m*n_mon].x   = fc_3[i].x;
	      fc_3a[i+m*n_mon].y   = fc_3[i].y;
	      fc_3a[i+m*n_mon].z   = fc_3[i].z;

	    }
	  }
	   
	
          for( i = 0; i < n_mon*n_fil; i++ )
          {
	    fa[i].x  += fc_3a[i].x;
	    fa[i].y  += fc_3a[i].y;
	    fa[i].z  += fc_3a[i].z;
	    
	    f_sv[i].x = fa[i].x;
	    f_sv[i].y = fa[i].y;
	    f_sv[i].z = fa[i].z;
	      
          }       
	 
	  verlet_pt2( r, v, fa ,tang, params );

      /* Fab */
	  if((k%10==0)&&(j>2))
	    {
	      fm_work += fabs(params.mass*(f[0].y+(fc_1[0].y+fc_2[0].y)/2)
			      *(r[0].y - y_old));   
	        

	      count++;
	    }
	  /* End Fab */

	  /* Mean velocity at every cycle*/

	  velx=0.0;
	  velz=0.0;

printf("\n");
	  for( i = 0; i < n_mon; i++ ){
	  printf("%e\t%e\t%e\n", v[i].x, v[i].y, v[i].z);
	      velx += v[i].x;
	      velz += v[i].z;}
printf("\n");

	  velx /= n_mon;
	  velz /= n_mon;

	  velocityx += velx;
	  velocityz += velz;


	  /*Position of the CM*/
	

	  for( i = 0; i < n_mon; i++ ){
	  rm[i].x += r[i].x;
	  rm[i].y += r[i].y;
	  rm[i].z += r[i].z;}


	  

    }

/*  fine ciclo temporale */
/*	  for( m = 0; m < n_fil; m++ ){
	 for(i=0; i<n_mon; i++)
	   rcm[m].z +=  r[i+m*n_mon].z;
	 rcm[m].z /= n_mon;}
*/
	  /*
       printf("old\trz0=%e\tzN=%e\trcmz0=%e\trcmz1=%e\t", r[0].z, r[n_mon].z, rcm[0].z, rcm[1].z);
	  
	       for( m = 0; m < n_fil; m++ ){
	 for(i=0; i<n_mon; i++)
	   r[i+m*n_mon].z -= rcm[m].z - m*dist;}
	       
       printf("new\trz0=%e\trzN=%e\n", r[0].z, r[n_mon].z);
       */

       /* Fab */
       y_amp = fabs(y_ampM - y_ampm)/2;
       
      
       
     /* Fab */ /* Accumulates average over cycles */
       velocityx /= params.n_cycle;
       velocityz /= params.n_cycle;
       velocity = sqrt(velocityx*velocityx+velocityz*velocityz);
	  
       	 //if(j==params.n_steps-1)   
	 printf("%i\t%le\t%le\t%le\t%le\n", j, velocity, velocityx, velocityz, y_amp);
       
       velocityx = 0.0;
       velocityz = 0.0;
	

//       velocity = (r[n_mon-1].z - z_start)/cycle_time;
       
       for( i = 0; i < n_mon; i++ ){
	 rm[i].x /= params.n_cycle;
	 rm[i].y /= params.n_cycle;
	 rm[i].z /= params.n_cycle;}
       
       
       output_data( rm, v, fa, params, step, &fper_ave, &fpar_ave );
       fflush( stdout );
	  


    
       ref_work = params.gamma * params.mass * n_mon;
       ref_work *= velocity*velocity;

       if(j>2){ 
	 TOT_fm_work  += fm_work/count;
	 TOT_velocity += velocity;
	 TOT_ref_work += ref_work;
	 
	 TOT_count++;
       }
       // printf(" %12.5g %12.5g\n", fm_work/count, ref_work);
       /* End Fab */

   }
/*  fine tutti cicli  */

     /* FM: Average over all cycles */
    AV_TOT_fm_work  = TOT_fm_work/TOT_count;
    AV_TOT_ref_work = TOT_ref_work/TOT_count;
    AV_TOT_velocity = TOT_velocity/TOT_count;

  
    sprintf(filename,"%sAV_VELOCITY",params.dir_name);
    file_ptr = fopen(filename,"w");
    fprintf(file_ptr,"%.16g %.16g %.16g %.16g\n"
	    ,Sperm_Number, (AV_TOT_velocity/(y_amp*y_amp)),
	    AV_TOT_velocity, y_amp); 
    fclose(file_ptr);

    sprintf(filename,"%sAV_WORK",params.dir_name);
    file_ptr = fopen(filename,"w");
    fprintf(file_ptr,"%.16g %.16g %.16g %.16g\n",Sperm_Number,
	    AV_TOT_fm_work, AV_TOT_ref_work,
	    AV_TOT_ref_work/AV_TOT_fm_work);   
    fclose(file_ptr);

    sprintf(filename,"%sAV_EFFICIENCY",params.dir_name);
    file_ptr = fopen(filename,"w");
    fprintf(file_ptr,"%.16g %.16g\n",Sperm_Number,
	    AV_TOT_ref_work/AV_TOT_fm_work);  
    fclose(file_ptr);

#ifdef TRANS
    sprintf(filename,"%sGL_DR",params.dir_name);
    file_ptr = fopen(filename,"w");
    for( l = 0; l < n_mon; l++ )
      {	 
	loc_dr  = (float)((constant_force.y * params.mass)/ (v[l].y));
	fprintf(file_ptr,"%.16g %.16g\n", 
		(float)l/(float)(n_mon-1),(n_mon)* loc_dr);  
      } 
    fclose(file_ptr);
#endif
    
#ifdef LONG
    sprintf(filename,"%sGL_DR",params.dir_name);
    file_ptr = fopen(filename,"w");
    for( l = 0; l < n_mon; l++ )
      {	 
	loc_dr  = (float)((constant_force.x * params.mass)/ (v[l].x));
	fprintf(file_ptr,"%.16g %.16g\n",  
		(float)l/(float)(n_mon-1), n_mon* loc_dr);  
      } 
    fclose(file_ptr);
#endif
   

}

/* ######################################################################### */

float  bending_forces( vec_s  *rij1,
		       float  *mags1,
		       vec_s  *f,
		       param_s params    )
/* ######################################################################### */
{


    int    n_mon, i;
   
    float  b_l, k, phi_0, u, m_inv;
 
    vec_s  f_di[3];
  

    n_mon = params.n_mon;
    b_l   = params.b_l;
    k     = params.k;
    phi_0 = params.phi_0;
    u     = 0.0;
    m_inv = 1.0/params.mass;
    for( i = 0; i < n_mon - 2; i++)
    {
       u += angle_force( rij1[i + 1], 
                         rij1[i+2], 
                         mags1[i+1], 
                         mags1[i+2],
                         k,
                         phi_0,
                         f_di);

       f[i].x += f_di[0].x*m_inv;
       f[i].y += f_di[0].y*m_inv;
       f[i].z += f_di[0].z*m_inv;
       f[i+1].x += f_di[1].x*m_inv;
       f[i+1].y += f_di[1].y*m_inv;
       f[i+1].z += f_di[1].z*m_inv;
       f[i+2].x += f_di[2].x*m_inv;
       f[i+2].y += f_di[2].y*m_inv;
       f[i+2].z += f_di[2].z*m_inv;
    }
    return( u );  
}

/* ########################################################################## */
float   angle_force( vec_s   r1,
                    vec_s   r2, 
                    float   r12,
                    float   r23,
                    float   k,
                    float   phi_0,
                    vec_s  *f )
/* ########################################################################## */
{
   int   i;

   float dprod, fac, u;
   float r12_3, r23_3, cphi, sphi, arg;

   dprod = r1.x*r2.x + r1.y*r2.y + r1.z*r2.z;
   cphi   = dprod/(r12*r23);

   u      = k*(1.0 - cphi);
   fac    = k;

   /*     sphi   = (1.0 - sqrt(cphi))/2.0; */
   /*     u      = k*(sphi)/2.0; */
   /*     fac    = k/4.0; */
 
   r12_3  = r12*r12*r12;
   r23_3  = r23*r23*r23;


   f[0].x =  r2.x/(r12*r23) - r1.x*dprod/(r12_3*r23);
   f[0].y =  r2.y/(r12*r23) - r1.y*dprod/(r12_3*r23);
   f[0].z =  r2.z/(r12*r23) - r1.z*dprod/(r12_3*r23);
   f[1].x = -r2.x*dprod/(r12*r23_3) + 
            (r1.x - r2.x)/(r12*r12) +
             r1.x*dprod/(r12_3*r23);
   f[1].y = -r2.y*dprod/(r12*r23_3) + 
            (r1.y - r2.y)/(r12*r12) +
             r1.y*dprod/(r12_3*r23);
   f[1].z = -r2.z*dprod/(r12*r23_3) + 
            (r1.z - r2.z)/(r12*r12) +
             r1.z*dprod/(r12_3*r23);
   f[2].x  = r2.x*dprod/(r12*r23_3) - r1.x/(r12*r23); 
   f[2].y  = r2.y*dprod/(r12*r23_3) - r1.y/(r12*r23); 
   f[2].z  = r2.z*dprod/(r12*r23_3) - r1.z/(r12*r23);
   for( i = 0; i < 3; i++ )
   {
      f[i].x *= fac;
      f[i].y *= fac;
      f[i].z *= fac;
   }
   return( u );
  
}
/* ########################################################################## */
void     constrain_positions( vec_s  *r1,
                              vec_s  *rij1,
                              vec_s  *v1,
                              param_s params )
/* ########################################################################## */
{
static int    init_flag = TRUE;
static float *a, *b, *c, *rhs, *ans;

    int   n_mon, n_c, i;
    float rijx, rijy, rijz, mag;
    float rhs_old, b_l, b_l_sq, max_error, error, tol;
    float dx, dy, dz, dt, disp1;

    n_mon   = params.n_mon;
    n_c     = n_mon - 1;
    tol     = params.tolerance;
    dt      = params.dt;
    b_l     = params.b_l;
    b_l_sq  = b_l*b_l;
    disp1    = 1.0/(1.0 + 0.5*params.gamma*params.dt);

    if( init_flag )
    {
        a      = (float *)malloc( (n_mon + 2)*sizeof( float )); 
        b      = (float *)malloc( (n_mon + 2)*sizeof( float )); 
        c      = (float *)malloc( (n_mon + 2)*sizeof( float )); 
        ans    = (float *)malloc( (n_mon + 2)*sizeof( float )); 
        rhs    = (float *)malloc( (n_mon + 2)*sizeof( float ));
        init_flag = FALSE;
    }
    for( i = 0; i < n_mon; i++ )
    {
        fc_2[i].x = 0.0;
        fc_2[i].y = 0.0;
        fc_2[i].z = 0.0;
    }
    ans[0]     = 0.0;
    ans[n_mon] = 0.0;
    rij1[0].x   = 0.0;
    rij1[0].y   = 0.0;
    rij1[0].z   = 0.0;
    rij1[n_c + 1].x = 0.0;
    rij1[n_c + 1].y = 0.0;
    rij1[n_c + 1].z = 0.0;

    rijx  = r1[0].x - r1[1].x;
    rijy  = r1[0].y - r1[1].y;
    rijz  = r1[0].z - r1[1].z;
    mag   = rijx*rijx + rijy*rijy + rijz*rijz; 

    a[1]   = 0.0;
    b[1]   = rij1[1].x*rijx;
    b[1]  += rij1[1].y*rijy;
    b[1]  += rij1[1].z*rijz;
    b[1]  *= 4.0;
    c[1]   = rij1[2].x*rijx;
    c[1]  += rij1[2].y*rijy;
    c[1]  += rij1[2].z*rijz;
    c[1]  *= -2.0;
    rhs[1] = b_l_sq - mag;

    rijx    = r1[n_c - 1].x - r1[n_c].x;
    rijy    = r1[n_c - 1].y - r1[n_c].y;
    rijz    = r1[n_c - 1].z - r1[n_c].z;
    mag     = rijx*rijx + rijy*rijy + rijz*rijz; 
    a[n_c]  = rij1[n_c - 1].x*rijx;
    a[n_c] += rij1[n_c - 1].y*rijy;
    a[n_c] += rij1[n_c - 1].z*rijz;
    a[n_c] *= -2.0;
    b[n_c]  = rij1[n_c].x*rijx;
    b[n_c] += rij1[n_c].y*rijy;
    b[n_c] += rij1[n_c].z*rijz;
    b[n_c] *= 4.0;
    c[n_c]  = 0.0;
    rhs[n_c]= b_l_sq - mag;
    for( i = 2; i < n_c; i++ )
    {
        rijx   = r1[i-1].x - r1[i].x;
        rijy   = r1[i-1].y - r1[i].y;
        rijz   = r1[i-1].z - r1[i].z;
        mag    = rijx*rijx + rijy*rijy + rijz*rijz; 
        a[i]   = -2.0*(rijx*rij1[i-1].x + rijy*rij1[i-1].y + rijz*rij1[i-1].z);
        b[i]   =  4.0*(rijx*rij1[i].x + rijy*rij1[i].y + rijz*rij1[i].z);
        c[i]   = -2.0*(rijx*rij1[i+1].x + rijy*rij1[i+1].y + rijz*rij1[i+1].z);
        rhs[i] = b_l_sq - mag;
    }
    do
    {  
       tridag( a, b, c, rhs, ans, n_c );
       max_error = 0.0;
       for( i = 1; i <= n_c; i++ )
       {
          rijx    = r1[i-1].x + rij1[i].x*ans[i] - rij1[i-1].x*ans[i-1] -
                   (r1[i].x + rij1[i+1].x*ans[i+1] - rij1[i].x*ans[i]);
          rijy    = r1[i-1].y + rij1[i].y*ans[i] - rij1[i-1].y*ans[i-1] -
                   (r1[i].y + rij1[i+1].y*ans[i+1] - rij1[i].y*ans[i]);
          rijz    = r1[i-1].z + rij1[i].z*ans[i] - rij1[i-1].z*ans[i-1] -
                   (r1[i].z + rij1[i+1].z*ans[i+1] - rij1[i].z*ans[i]);
          mag     = rijx*rijx + rijy*rijy + rijz*rijz;
          error   = (sqrt(mag) - b_l)/b_l;
          rhs_old = rhs[i];
          rhs[i]  = a[i]*ans[i-1] + b[i]*ans[i] + c[i]*ans[i+1];
          rhs[i]  = b_l_sq - mag + rhs[i];
          if( error > max_error )
          {
              max_error = error;
          }
       }
    }while( max_error > tol ); 
    for( i = 0; i < n_mon; i++ )
    {
       dx      = rij1[i+1].x*ans[i+1] - rij1[i].x*ans[i];
       dy      = rij1[i+1].y*ans[i+1] - rij1[i].y*ans[i];
       dz      = rij1[i+1].z*ans[i+1] - rij1[i].z*ans[i];

       r1[i].x += dx;
       r1[i].y += dy;
       r1[i].z += dz;
     

     /*  v[i].x += disp1*dx/(2.0*dt);
       v[i].y += disp1*dy/(2.0*dt);
       v[i].z += disp1*dz/(2.0*dt);*/
       fc_2[i].x = 2.0*dx/(dt*dt);
       fc_2[i].y = 2.0*dy/(dt*dt);
       fc_2[i].z = 2.0*dz/(dt*dt);
    }
 
}
/* ########################################################################## */
void     constrain_velocities(  vec_s  *rij,
                                float  *mag,
                                vec_s  *v1,
                                param_s params )
       
/* ########################################################################## */
{
static int    init_flag = TRUE;
static float *a, *b, *c, *rhs, *ans, dt;

    int   n_mon, n_c, i;

    n_mon   = params.n_mon;
    n_c     = n_mon - 1;

    if( init_flag )
    {
        a      = (float *)malloc( (n_mon + 2)*sizeof( float )); 
        b      = (float *)malloc( (n_mon + 2)*sizeof( float )); 
        c      = (float *)malloc( (n_mon + 2)*sizeof( float )); 
        ans    = (float *)malloc( (n_mon + 2)*sizeof( float )); 
        rhs    = (float *)malloc( (n_mon + 2)*sizeof( float ));
        dt     = params.dt;
        init_flag = FALSE;
    }
    for( i = 0; i < n_mon; i++ )
    {
        fc_1[i].x = 0.0;
        fc_1[i].y = 0.0;
        fc_1[i].z = 0.0;
    }
    for( i = 1; i <= n_c; i++ )
    {
        rhs[i]  = (v1[i-1].x - v1[i].x)*rij[i].x;
        rhs[i] += (v1[i-1].y - v1[i].y)*rij[i].y;
        rhs[i] += (v1[i-1].z - v1[i].z)*rij[i].z;
        rhs[i] /= mag[i];
        a[i]    = rij[i-1].x*rij[i].x +
                  rij[i-1].y*rij[i].y +
                  rij[i-1].z*rij[i].z;
        b[i]    = -2.0*( rij[i].x*rij[i].x +
                   rij[i].y*rij[i].y +
                   rij[i].z*rij[i].z);
        c[i]    = rij[i].x*rij[i+1].x +
                  rij[i].y*rij[i+1].y +
                  rij[i].z*rij[i+1].z;
         a[i]  /= (mag[i]*mag[i]);
         b[i]  /= (mag[i]*mag[i]);
         c[i]  /= (mag[i]*mag[i]);
     }
     tridag( a, b, c, rhs, ans, n_c );
     for( i = 1; i <= n_c; i++ )
     {

       v1[i-1].x += ans[i]*rij[i].x/mag[i];
       v1[i-1].y += ans[i]*rij[i].y/mag[i];
       v1[i-1].z += ans[i]*rij[i].z/mag[i];
       v1[i].x   -= ans[i]*rij[i].x/mag[i];
       v1[i].y   -= ans[i]*rij[i].y/mag[i];
       v1[i].z   -= ans[i]*rij[i].z/mag[i];
       fc_1[i-1].x += ans[i]*rij[i].x/(dt*mag[i]);
       fc_1[i-1].y += ans[i]*rij[i].y/(dt*mag[i]);
       fc_1[i-1].z += ans[i]*rij[i].z/(dt*mag[i]);
       fc_1[i].x   -= ans[i]*rij[i].x/(dt*mag[i]);
       fc_1[i].y   -= ans[i]*rij[i].y/(dt*mag[i]);
       fc_1[i].z   -= ans[i]*rij[i].z/(dt*mag[i]);
       
     }
     


}

/* ########################################################################## */
void     constrain_forces(      vec_s  *rij1,
                                float  *mags1,
                                vec_s  *f,
                                param_s params )

/* ########################################################################## */
{
static int    init_flag = TRUE;
static float *a, *b, *c, *rhs, *ans, dt;

    int   n_mon, n_c, i;

    n_mon   = params.n_mon;
    n_c     = n_mon - 1;

    if( init_flag )
    {
        a      = (float *)malloc( (n_mon + 2)*sizeof( float ));
        b      = (float *)malloc( (n_mon + 2)*sizeof( float ));
        c      = (float *)malloc( (n_mon + 2)*sizeof( float ));
        ans    = (float *)malloc( (n_mon + 2)*sizeof( float ));
        rhs    = (float *)malloc( (n_mon + 2)*sizeof( float ));
        dt     = params.dt;
        init_flag = FALSE;
    }
    for( i = 0; i < n_mon; i++ )
    {
        fc_3[i].x = 0.0;
        fc_3[i].y = 0.0;
        fc_3[i].z = 0.0;
    }
    for( i = 1; i <= n_c; i++ )
    {
        rhs[i]  = (f[i-1].x - f[i].x)*rij1[i].x;
        rhs[i] += (f[i-1].y - f[i].y)*rij1[i].y;
        rhs[i] += (f[i-1].z - f[i].z)*rij1[i].z;
        rhs[i] /= mags1[i];
        a[i]    = rij1[i-1].x*rij1[i].x +
                  rij1[i-1].y*rij1[i].y +
                  rij1[i-1].z*rij1[i].z;
        b[i]    = -2.0*( rij1[i].x*rij1[i].x +
                   rij1[i].y*rij1[i].y +
                   rij1[i].z*rij1[i].z);
        c[i]    = rij1[i].x*rij1[i+1].x +
                  rij1[i].y*rij1[i+1].y +
                  rij1[i].z*rij1[i+1].z;
         a[i]  /= (mags1[i]*mags1[i]);
         b[i]  /= (mags1[i]*mags1[i]);
         c[i]  /= (mags1[i]*mags1[i]);
     }
     tridag( a, b, c, rhs, ans, n_c );
     for( i = 1; i <= n_c; i++ )
     {
         fc_3[i-1].x += ans[i]*rij1[i].x/(mags1[i]);
         fc_3[i-1].y += ans[i]*rij1[i].y/(mags1[i]);
         fc_3[i-1].z += ans[i]*rij1[i].z/(mags1[i]);
         fc_3[i].x   -= ans[i]*rij1[i].x/(mags1[i]);
         fc_3[i].y   -= ans[i]*rij1[i].y/(mags1[i]);
         fc_3[i].z   -= ans[i]*rij1[i].z/(mags1[i]);

     }
}

/* ########################################################################## */
float    verlet_pt1(  vec_s  *r,
                      vec_s  *v,
                      vec_s  *fa,
                      vec_s  *tang,
                      param_s parameters )
       
/* ########################################################################## */
{
  static char  init_flag = TRUE;
  static float dt, half_dt, half_dt_sq;
  static float hydr_radius, gamma, massa;
  static float disp1, disp2;
  static float gamma_0, disp1_0, disp2_0;
  static float bond;
  static vec_s *v_h = NULL;
  static int  n_mon, n_fil;

  float ddx, ddy, ddz;
  int  i;
  vec_s f_i, v_norm, v_hydr;
  

    if( init_flag )
    {

        dt             = parameters.dt;
	bond           = parameters.b_l;
	hydr_radius    = parameters.hydr_radius;
	gamma          = parameters.gamma /*  * (hydr_radius*bond) */;
        gamma_0        = parameters.gamma_head;
	massa          = parameters.mass;
	disp1          = 1.0/(1.0 + 0.5*gamma*dt);
	disp1_0        = 1.0/(1.0 + 0.5*gamma_0*dt);
	n_fil          = parameters.n_fil;
	n_mon          = parameters.n_mon;

	//	disp2          = (1.0 - 0.5*gamma*dt)*disp1;
	//	disp2_0        = (1.0 - 0.5*gamma_0*dt)*disp1_0;

        half_dt    = dt/2.0;
        half_dt_sq = dt*dt/2.0;
        init_flag  = FALSE;
    }

    if(v_h == NULL){
      v_h = (vec_s *)malloc(n_mon*n_fil*sizeof( vec_s ));     
    }


    oseen(r, fa, v_h, parameters);
 
   
    for( i = 0; i < n_mon*n_fil; i++ )
    {

        f_i.x      = fa[i].x;
        f_i.y      = fa[i].y;
        f_i.z      = fa[i].z;

	
        v_norm.x   = v[i].x;
        v_norm.y   = v[i].y;
        v_norm.z   = v[i].z;
	

	
	v_hydr.x   = v_h[i].x; 
 	v_hydr.y   = v_h[i].y;
	v_hydr.z   = v_h[i].z;




  
        ddx     = v_norm.x*dt + (f_i.x + gamma*(v_hydr.x-v_norm.x))*half_dt_sq;
        ddy     = v_norm.y*dt + (f_i.y + gamma*(v_hydr.y-v_norm.y))*half_dt_sq;
        ddz     = v_norm.z*dt + (f_i.z + gamma*(v_hydr.z-v_norm.z))*half_dt_sq;


        r[i].x      += ddx;
        r[i].y      += ddy;
	r[i].z      += ddz;
	 
	

     v_norm.x = disp1*(v_norm.x + (f_i.x + gamma*(v_hydr.x-v_norm.x))*half_dt);
     v_norm.y = disp1*(v_norm.y + (f_i.y + gamma*(v_hydr.y-v_norm.y))*half_dt);
     v_norm.z = disp1*(v_norm.z + (f_i.z + gamma*(v_hydr.z-v_norm.z))*half_dt);


       

       v[i].x        = v_norm.x;
       v[i].y        = v_norm.y;
       v[i].z        = v_norm.z;



    }
    
   
    return( parameters.mass/2.0);
} 
/* ########################################################################## */
void      verlet_pt2(  vec_s  *r,
                       vec_s  *v,
                       vec_s  *fa,
                       vec_s  *tang,
                       param_s parameters )
       
/* ########################################################################## */
{
  static char  init_flag = TRUE;
  static float dt, half_dt, half_dt_sq, disp1;
  static float gamma, gamma_0, disp1_0, massa;
  static float bond, hydr_radius;
  static vec_s *v_hyd = NULL;
  static int n_mon, n_fil;
  int  i;

  vec_s f_i, v_norm, v_hydro;

    if( init_flag )
    {
        dt         = parameters.dt;
	bond       = parameters.b_l;
	hydr_radius = parameters.hydr_radius;
        gamma_0    = parameters.gamma_head;
	gamma      = parameters.gamma;
        half_dt    = dt/2.0;
        half_dt_sq = dt*dt/2.0;
	massa      = parameters.mass;
	disp1      = 1.0/(1.0 + 0.5*gamma*dt);
	disp1_0    = 1.0/(1.0 + 0.5*gamma_0*dt);
	n_fil      = parameters.n_fil;
	n_mon      = parameters.n_mon;

        init_flag  = FALSE;
    }
    if(v_hyd == NULL)
      v_hyd = (vec_s *)malloc( n_mon*n_fil*sizeof( vec_s ));

    oseen(r, fa, v_hyd, parameters);

    for( i = 0; i < n_fil*n_mon; i++ )
    {

        f_i.x      = fa[i].x;
        f_i.y      = fa[i].y;
        f_i.z      = fa[i].z;
   

	v_norm.x   = v[i].x;
        v_norm.y   = v[i].y;
        v_norm.z   = v[i].z;
	
	v_hydro.x   = v_hyd[i].x;
 	v_hydro.y   = v_hyd[i].y;
	v_hydro.z   = v_hyd[i].z;



     v_norm.x = disp1* (f_i.x + gamma*(v_hydro.x))*half_dt;
     v_norm.y = disp1* (f_i.y + gamma*(v_hydro.y))*half_dt;
     v_norm.z = disp1* (f_i.z + gamma*(v_hydro.z))*half_dt;
       
       v[i].x      += v_norm.x;
       v[i].y      += v_norm.y;
       v[i].z      += v_norm.z;


    }
}


/*  ************************************************************************ */

void     oseen( vec_s *r,
		vec_s *fa,
		vec_s *v_h,
		param_s parameters)
/*  ************************************************************************ */
{
  static float hydr_radius, gamma, gamma_0, bond, massa;
  static char  init_flag = TRUE;
  static int n_mon, n_fil;
  
  float rijx, rijy,rijz;
  float mag_ij;
  int  i,j,k; 
  vec_s r_i, r_j, f_i, f_j, v_hydr;

  if( init_flag )
    {
      gamma          = parameters.gamma*parameters.mass;
      hydr_radius    = parameters.hydr_radius;
      gamma_0        = parameters.gamma_head*parameters.mass;
      bond           = parameters.b_l;
      massa          = parameters.mass;
      n_fil          = parameters.n_fil;
      n_mon          = parameters.n_mon;        
      init_flag  = FALSE;
    }



  /*    printf("hydrodynamic radius is %f", hydr_radius); */
  
  for( i = 0; i < n_mon*n_fil; i++ )
    {

      v_hydr.x = 0;
      v_hydr.y = 0;
      v_hydr.z = 0;
      
      
      r_i.x      = r[i].x;
      r_i.y      = r[i].y;
      r_i.z      = r[i].z; 

      f_i.x      = massa * fa[i].x;
      f_i.y      = massa * fa[i].y;
      f_i.z      = massa * fa[i].z;
      
      for( j = 0; j <  n_mon*n_fil; j++)
	{
	  
	  f_j.x      = massa * fa[j].x;
	  f_j.y      = massa * fa[j].y;
	  f_j.z      = massa * fa[j].z;
	  
	  r_j.x      = r[j].x;
	  r_j.y      = r[j].y;
	  r_j.z      = r[j].z;
	
	  rijx     = r[i].x - r[j].x;
	  rijy     = r[i].y - r[j].y;
	  rijz     = r[i].z - r[j].z;

	  mag_ij  = sqrt(rijx*rijx + rijy*rijy + rijz*rijz);
	  
	  rijx    /= mag_ij;
	  rijy    /= mag_ij;
	  rijz    /= mag_ij;
	  
	  mag_ij  /= bond;
	  
	  if(j != i)
	    {
	      v_hydr.x += ((1+ rijx * rijx)* f_j.x +
			   (rijx * rijy)   * f_j.y +
			   (rijx * rijz)   * f_j.z  ) / mag_ij;
	      
	      v_hydr.y += ((rijx* rijy)    * f_j.x +
			   (1+ rijy * rijy)* f_j.y +
			   (rijy * rijz)   * f_j.z  ) / mag_ij;
		
	      v_hydr.z += ((rijz * rijx)   * f_j.x +
			   (rijz * rijy)   * f_j.y +
			   (1+ rijz * rijz)* f_j.z  ) / mag_ij;
	    }
	  
	  
	}

      v_h[i].x = (0.75 * v_hydr.x ) *  (hydr_radius/ gamma);
      v_h[i].y = (0.75 * v_hydr.y ) *  (hydr_radius/ gamma);
      v_h[i].z = (0.75 * v_hydr.z ) *  (hydr_radius/ gamma);
	
    }




}


    static  float *dx, *dy;
    static  vec_s *f_old;
    static float w;


/* ########################################################################## */
float      boundary_conditions( vec_s *r,
                                vec_s *v,
                                vec_s *f,
                                vec_s *tang,
                                param_s params,
                                int n_step,
                                int sstp )
/* ########################################################################## */
{
    static  vec_s *r_old;
    static  int   init_flag = TRUE;
    static  float b_l, w_length, freq, amp, l;
    static  int   n_mon, n_left, n_right, n_fil; 
    static  float gamma, hydr_radius;
    
    int   j,i;
    float v_new, t;
    float rijx, rijy, r0x, r0y, r0z, arg;
    float fac, x, dprod;
    float fx_tot, fy_tot, fz_tot;

/*ILl*/float aa1, aa2, bb1, bb2, cc1, cc2, A1, A2, denom, denom1, num;
    vec_s v_per, v_par;

    if( init_flag )
    {
        n_mon    = params.n_mon;
	n_fil    = params.n_fil;
        b_l      = params.b_l;
        n_left   = params.n_left;
        n_right  = params.n_right;
        w_length = params.w_length;
        freq     = params.freq;
         amp      = params.amp;
        gamma    = params.gamma;
	hydr_radius = params.hydr_radius;
        l        = 1.0 - n_left*b_l - n_right*b_l;
        dx       = (float *)malloc( params.n_mon*sizeof( float ));
        dy       = (float *)malloc( params.n_mon*sizeof( float ));
        r_old    = (vec_s *)malloc( params.n_mon*sizeof( vec_s ));
        f_old    = (vec_s *)malloc( params.n_mon*sizeof( vec_s ));
        for( j = 0; j < params.n_mon; j++ )
	        {
           dx[j] = 0.0;
           dy[j] = 0.0;
        }
#ifdef EQUIL 
	freq      = 0.0;
#endif

        init_flag = FALSE;
    }


    t      = n_step*params.dt;
    w       = 0.0;


    for( i = n_left + 1; i < n_mon - n_right - 1; i++ )
    {
       x         = (i - n_left)*b_l/l;
#ifdef SQUARE 
       fac     = cos( w_length*2.0*PI*x - freq*t);
       if( fac > 0.0 )
          fac =  1.0;
       else
          fac = -1.0;
        
       fac  *= amp;
#endif

#ifdef STARTMODE 

      /*   QUI! metti if cycle <relax fac = amp cos(wl 2 Pi x)*/
       //nb nonfzia se amp aumenta con Sp!!!
       if(sstp < 20){
       fac       =  amp*cos( w_length*2.0*PI*x);
       }
       else{
       fac       =  amp*cos( w_length*2.0*PI*x - freq*t);
       }

#else

       fac       =  amp*cos( w_length*2.0*PI*x - freq*t);


#endif
       //       t_ext[i]  = fac;

 

	   r0x       =  (r[i].x + r[i+1].x)/2.0;
       r0y       =  (r[i].y + r[i+1].y)/2.0;
	   r0z       =  (r[i].z + r[i+1].z)/2.0;
	   
	   aa1 =  (r[i+1].x - r0x);
	   bb1 =  (r[i+1].y - r0y);
	   cc1 =  (r[i+1].z - r0z);
	   
	   aa2 =  (r[i+1].y - r0y)*(r0z - r[i].z) - (r[i+1].z - r0z)*(r0y - r[i].y);
	   bb2 =  (r[i+1].z - r0z)*(r0x - r[i].x) - (r[i+1].x - r0x)*(r0z - r[i].z);
	   cc2 =  (r[i+1].x - r0x)*(r0y - r[i].y) - (r[i+1].y - r0y)*(r0x - r[i].x);

	   denom1 = aa2*cc1-aa1*cc2;

	   if(denom1==0.0)
		{A1=0.0;
		A2=0.0;}
	   else
		{

		A1 = (bb1*cc2-bb2*cc1)/(aa2*cc1-aa1*cc2);
		A2 = (bb2*aa1-bb1*aa2)/(aa2*cc1-aa1*cc2);
	   }
	   
	   denom = sqrt(1.0+A1*A1+A2*A2);
	   num = sqrt(aa1*aa1+bb1*bb1+cc1*cc1);

	   
       f[i+1].x += num*A1*fac/denom;
       f[i+1].y += num*fac/denom;
	   f[i+1].z += num*A2*fac/denom;
	   
	   printf("11\taa1=%e aa2=%e bb1=%e bb2=%e cc1=%e cc2=%e A1=%e A2=%e denom=%e\n", aa1, aa2, bb1, bb2, cc1, cc2, A1, A2, denom);
	   
	   aa1 =  (r0x - r[i].x);
	   bb1 =  (r0y - r[i].y);
	   cc1 =  (r0z - r[i].z);
	   
	   aa2 =  (r[i+1].y - r0y)*(r0z - r[i].z) - (r[i+1].z - r0z)*(r0y - r[i].y);
	   bb2 =  (r[i+1].z - r0z)*(r0x - r[i].x) - (r[i+1].x - r0x)*(r0z - r[i].z);
	   cc2 =  (r[i+1].x - r0x)*(r0y - r[i].y) - (r[i+1].y - r0y)*(r0x - r[i].x);


       denom1 = aa2*cc1-aa1*cc2;

	   if(denom1==0.0)
		{A1=0.0;
		A2=0.0;}
	   else
		{

		A1 = (bb1*cc2-bb2*cc1)/(aa2*cc1-aa1*cc2);
		A2 = (bb2*aa1-bb1*aa2)/(aa2*cc1-aa1*cc2);
	   }

	   
	   denom = sqrt(1.0+A1*A1+A2*A2);
	   num = sqrt(aa1*aa1+bb1*bb1+cc1*cc1);

	   f[i].x += num*A1*fac/denom;
       f[i].y += num*fac/denom;
	   f[i].z += num*A2*fac/denom;

	   printf("22\taa1=%e aa2=%e bb1=%e bb2=%e cc1=%e cc2=%e A1=%e A2=%e denom=%e\n", aa1, aa2, bb1, bb2, cc1, cc2, A1, A2, denom);



       r0x       =  (r[i].x + r[i-1].x)/2.0;
       r0y       =  (r[i].y + r[i-1].y)/2.0;
	   r0z       =  (r[i].z + r[i-1].z)/2.0;
       

	   aa1 =  -(r[i-1].x - r0x);
	   bb1 =  -(r[i-1].y - r0y);
	   cc1 =  -(r[i-1].z - r0z);
	   
	   aa2 =  (r[i-1].y - r0y)*(r0z - r[i].z) - (r[i-1].z - r0z)*(r0y - r[i].y);
	   bb2 =  (r[i-1].z - r0z)*(r0x - r[i].x) - (r[i-1].x - r0x)*(r0z - r[i].z);
	   cc2 =  (r[i-1].x - r0x)*(r0y - r[i].y) - (r[i-1].y - r0y)*(r0x - r[i].x);

	   denom1 = aa2*cc1-aa1*cc2;

	   if(denom1==0.0)
		{A1=0.0;
		A2=0.0;}
	   else
		{

		A1 = (bb1*cc2-bb2*cc1)/(aa2*cc1-aa1*cc2);
		A2 = (bb2*aa1-bb1*aa2)/(aa2*cc1-aa1*cc2);
	   }
	   
	   denom = sqrt(1.0+A1*A1+A2*A2);
	 num = sqrt(aa1*aa1+bb1*bb1+cc1*cc1);
  
	   
       f[i-1].x += num*A1*fac/denom;
       f[i-1].y += num*fac/denom;
	   f[i-1].z += num*A2*fac/denom;

	   printf("33\taa1=%e aa2=%e bb1=%e bb2=%e cc1=%e cc2=%e A1=%e A2=%e denom=%e\n", aa1, aa2, bb1, bb2, cc1, cc2, A1, A2, denom);


	   aa1 =  (r[i].x - r0x);
	   bb1 =  (r[i].y - r0y);
	   cc1 =  (r[i].z - r0z);
	   
	   aa2 =  (r[i-1].y - r0y)*(r0z - r[i].z) - (r[i-1].z - r0z)*(r0y - r[i].y);
	   bb2 =  (r[i-1].z - r0z)*(r0x - r[i].x) - (r[i-1].x - r0x)*(r0z - r[i].z);
	   cc2 =  (r[i-1].x - r0x)*(r0y - r[i].y) - (r[i-1].y - r0y)*(r0x - r[i].x);

	    denom1 = aa2*cc1-aa1*cc2;

	   if(denom1==0.0)
		{A1=0.0;
		A2=0.0;}
	   else
		{

		A1 = (bb1*cc2-bb2*cc1)/(aa2*cc1-aa1*cc2);
		A2 = (bb2*aa1-bb1*aa2)/(aa2*cc1-aa1*cc2);
	   }
	   
	   denom = sqrt(1.0+A1*A1+A2*A2);
num = sqrt(aa1*aa1+bb1*bb1+cc1*cc1);
       
	   f[i].x += num*A1*fac/denom;
       f[i].y += num*fac/denom;
	   f[i].z += num*A2*fac/denom;
	   
	   printf("44\taa1=%e aa2=%e bb1=%e bb2=%e cc1=%e cc2=%e A1=%e A2=%e denom=%e\n", aa1, aa2, bb1, bb2, cc1, cc2, A1, A2, denom);

    
	



/*
       r0x       =  (r[i].x + r[i+1].x)/2.0;
       r0y       =  (r[i].y + r[i+1].y)/2.0;
       rijx      = +(r[i+1].x - r0x);
       rijy      = -(r[i+1].y - r0y);
       f[i+1].x += rijy*fac;
       f[i+1].y += rijx*fac;

       rijx      = +(r[i].x - r0x);
       rijy      = -(r[i].y - r0y);
       f[i].x += rijy*fac;
       f[i].y += rijx*fac;

       r0x       =  (r[i].x + r[i-1].x)/2.0;
       r0y       =  (r[i].y + r[i-1].y)/2.0;
       rijx      =  -(r[i-1].x - r0x);
       rijy      =  +(r[i-1].y - r0y);

       f[i-1].x += rijy*fac;
       f[i-1].y += rijx*fac;
       rijx      =  -(r[i].x - r0x);
       rijy      =  +(r[i].y - r0y);
       f[i].x   += rijy*fac;
       f[i].y   += rijx*fac;*/
	   
	   
    }
    if( n_step > 0 )
    {
      fx_tot = 0.0;
      fy_tot = 0.0;
      
      for( i = 0; i < n_mon; i++ )
	{
	  fx_tot += f[i].x;
	  fy_tot += f[i].y;
	  
       }
      fx_tot /= n_mon;
      fy_tot /= n_mon;
      
 

      for( i = 0; i < n_mon; i++ )
       {
          dx[i]  = r[i].x - r_old[i].x;
          dy[i]  = r[i].y - r_old[i].y;
          w  += params.mass*(dx[i]*f_old[i].x + dy[i]*f_old[i].y);
          r_old[i].x = r[i].x;
          r_old[i].y = r[i].y;
          f[i].x -= fx_tot;
	      f[i].y -= fy_tot;
          f_old[i].x = f[i].x;
          f_old[i].y = f[i].y; 

       }
    }
 

  for( i = n_left + n_mon + 1; i < n_fil*n_mon - n_right - 1; i++ )
    {
       x         = (i - n_left - n_mon)*b_l/l;
#ifdef SQUARE 
       fac     = cos( w_length*2.0*PI*x - freq*t);
       if( fac > 0.0 )
          fac =  1.0;
       else
          fac = -1.0;
        
       fac  *= amp;
#endif

#ifdef STARTMODE 

      /*   QUI! metti if cycle <relax fac = amp cos(wl 2 Pi x)*/
       //nb nonfzia se amp aumenta con Sp!!!
       if(sstp < 20){
       fac       =  amp*cos( w_length*2.0*PI*x);
       }
       else{
       fac       =  amp*cos( w_length*2.0*PI*x - freq*t);
       }

#else

       fac       =  amp*cos( w_length*2.0*PI*x - freq*t);


#endif
       //       t_ext[i]  = fac;

   /*    r0x       =  (r[i].x + r[i+1].x)/2.0;
       r0y       =  (r[i].y + r[i+1].y)/2.0;
       rijx      = +(r[i+1].x - r0x);
       rijy      = -(r[i+1].y - r0y);
       f[i+1].x += rijy*fac;
       f[i+1].y += rijx*fac;

       rijx      = +(r[i].x - r0x);
       rijy      = -(r[i].y - r0y);
       f[i].x += rijy*fac;
       f[i].y += rijx*fac;

       r0x       =  (r[i].x + r[i-1].x)/2.0;
       r0y       =  (r[i].y + r[i-1].y)/2.0;
       rijx      =  -(r[i-1].x - r0x);
       rijy      =  +(r[i-1].y - r0y);

       f[i-1].x += rijy*fac;
       f[i-1].y += rijx*fac;
       rijx      =  -(r[i].x - r0x);
       rijy      =  +(r[i].y - r0y);
       f[i].x   += rijy*fac;
       f[i].y   += rijx*fac;*/
	   
	  
	   r0x       =  (r[i].x + r[i+1].x)/2.0;
       r0y       =  (r[i].y + r[i+1].y)/2.0;
	   r0z       =  (r[i].z + r[i+1].z)/2.0;
	   
	   aa1 =  (r[i+1].x - r0x);
	   bb1 =  (r[i+1].y - r0y);
	   cc1 =  (r[i+1].z - r0z);
	   
	   aa2 =  (r[i+1].y - r0y)*(r0z - r[i].z) - (r[i+1].z - r0z)*(r0y - r[i].y);
	   bb2 =  (r[i+1].z - r0z)*(r0x - r[i].x) - (r[i+1].x - r0x)*(r0z - r[i].z);
	   cc2 =  (r[i+1].x - r0x)*(r0y - r[i].y) - (r[i+1].y - r0y)*(r0x - r[i].x);

	   denom1 = aa2*cc1-aa1*cc2;

	   if(denom1==0.0)
		{A1=0.0;
		A2=0.0;}
	   else
		{

		A1 = (bb1*cc2-bb2*cc1)/(aa2*cc1-aa1*cc2);
		A2 = (bb2*aa1-bb1*aa2)/(aa2*cc1-aa1*cc2);
	   }
	   
	   denom = sqrt(1.0+A1*A1+A2*A2);
	   num = sqrt(aa1*aa1+bb1*bb1+cc1*cc1);

	   
       f[i+1].x += num*A1*fac/denom;
       f[i+1].y += num*fac/denom;
	   f[i+1].z += num*A2*fac/denom;
	   
	   printf("2\t11\taa1=%e aa2=%e bb1=%e bb2=%e cc1=%e cc2=%e A1=%e A2=%e denom=%e\n", aa1, aa2, bb1, bb2, cc1, cc2, A1, A2, denom);
	   
	   aa1 =  (r0x - r[i].x);
	   bb1 =  (r0y - r[i].y);
	   cc1 =  (r0z - r[i].z);
	   
	   aa2 =  (r[i+1].y - r0y)*(r0z - r[i].z) - (r[i+1].z - r0z)*(r0y - r[i].y);
	   bb2 =  (r[i+1].z - r0z)*(r0x - r[i].x) - (r[i+1].x - r0x)*(r0z - r[i].z);
	   cc2 =  (r[i+1].x - r0x)*(r0y - r[i].y) - (r[i+1].y - r0y)*(r0x - r[i].x);


       denom1 = aa2*cc1-aa1*cc2;

	   if(denom1==0.0)
		{A1=0.0;
		A2=0.0;}
	   else
		{

		A1 = (bb1*cc2-bb2*cc1)/(aa2*cc1-aa1*cc2);
		A2 = (bb2*aa1-bb1*aa2)/(aa2*cc1-aa1*cc2);
	   }

	   
	   denom = sqrt(1.0+A1*A1+A2*A2);
	   num = sqrt(aa1*aa1+bb1*bb1+cc1*cc1);

	   f[i].x += num*A1*fac/denom;
       f[i].y += num*fac/denom;
	   f[i].z += num*A2*fac/denom;

	   printf("2\t22\taa1=%e aa2=%e bb1=%e bb2=%e cc1=%e cc2=%e A1=%e A2=%e denom=%e\n", aa1, aa2, bb1, bb2, cc1, cc2, A1, A2, denom);



       r0x       =  (r[i].x + r[i-1].x)/2.0;
       r0y       =  (r[i].y + r[i-1].y)/2.0;
	   r0z       =  (r[i].z + r[i-1].z)/2.0;
       

	   aa1 =  -(r[i-1].x - r0x);
	   bb1 =  -(r[i-1].y - r0y);
	   cc1 =  -(r[i-1].z - r0z);
	   
	   aa2 =  (r[i-1].y - r0y)*(r0z - r[i].z) - (r[i-1].z - r0z)*(r0y - r[i].y);
	   bb2 =  (r[i-1].z - r0z)*(r0x - r[i].x) - (r[i-1].x - r0x)*(r0z - r[i].z);
	   cc2 =  (r[i-1].x - r0x)*(r0y - r[i].y) - (r[i-1].y - r0y)*(r0x - r[i].x);

	   denom1 = aa2*cc1-aa1*cc2;

	   if(denom1==0.0)
		{A1=0.0;
		A2=0.0;}
	   else
		{

		A1 = (bb1*cc2-bb2*cc1)/(aa2*cc1-aa1*cc2);
		A2 = (bb2*aa1-bb1*aa2)/(aa2*cc1-aa1*cc2);
	   }
	   
	   denom = sqrt(1.0+A1*A1+A2*A2);
	   num = sqrt(aa1*aa1+bb1*bb1+cc1*cc1);

	   
       f[i-1].x += num*A1*fac/denom;
       f[i-1].y += num*fac/denom;
	   f[i-1].z += num*A2*fac/denom;

	   printf("2\t33\taa1=%e aa2=%e bb1=%e bb2=%e cc1=%e cc2=%e A1=%e A2=%e denom=%e\n", aa1, aa2, bb1, bb2, cc1, cc2, A1, A2, denom);


	   aa1 =  (r[i].x - r0x);
	   bb1 =  (r[i].y - r0y);
	   cc1 =  (r[i].z - r0z);
	   
	   aa2 =  (r[i-1].y - r0y)*(r0z - r[i].z) - (r[i-1].z - r0z)*(r0y - r[i].y);
	   bb2 =  (r[i-1].z - r0z)*(r0x - r[i].x) - (r[i-1].x - r0x)*(r0z - r[i].z);
	   cc2 =  (r[i-1].x - r0x)*(r0y - r[i].y) - (r[i-1].y - r0y)*(r0x - r[i].x);

	    denom1 = aa2*cc1-aa1*cc2;

	   if(denom1==0.0)
		{A1=0.0;
		A2=0.0;}
	   else
		{

		A1 = (bb1*cc2-bb2*cc1)/(aa2*cc1-aa1*cc2);
		A2 = (bb2*aa1-bb1*aa2)/(aa2*cc1-aa1*cc2);
	   }
	   
	   denom = sqrt(1.0+A1*A1+A2*A2);
num = sqrt(aa1*aa1+bb1*bb1+cc1*cc1);

       
	   f[i].x += num*A1*fac/denom;
       f[i].y += num*fac/denom;
	   f[i].z += num*A2*fac/denom;
	   
	   printf("2\t44\taa1=%e aa2=%e bb1=%e bb2=%e cc1=%e cc2=%e A1=%e A2=%e denom=%e\n", aa1, aa2, bb1, bb2, cc1, cc2, A1, A2, denom);

    
 
	   
    }
  if( n_step > 0 )
    {
      fx_tot = 0.0;
      fy_tot = 0.0;
      
      for( i = n_mon; i < n_fil*n_mon; i++ )
	{
	  fx_tot += f[i].x;
	  fy_tot += f[i].y;
	  
       }
      fx_tot /= n_mon;
      fy_tot /= n_mon;

    for( i = n_mon; i < n_fil*n_mon; i++ )
       {
          dx[i]  = r[i].x - r_old[i].x;
          dy[i]  = r[i].y - r_old[i].y;
          w  += params.mass*(dx[i]*f_old[i].x + dy[i]*f_old[i].y);
          r_old[i].x = r[i].x;
          r_old[i].y = r[i].y;
	  f[i].x -= fx_tot;
	  f[i].y -= fy_tot;
          f_old[i].x = f[i].x;
          f_old[i].y = f[i].y;
	  
       }


    }
    return( w );

}     
 

/* ########################################################################## */
void     output_data(  vec_s  *r,
                       vec_s  *v,
                       vec_s  *f,
		       param_s params,
                       int     step,
                       float   *fper_ave,
                       float   *fpar_ave       )
/* ########################################################################## */
{
    FILE  *out_file_1, *out_file_2, *out_file_3;
    char  file_name[MAX_BUFF];
    int   i,j, n_mon;
    float rijx, rijy, rijz, rij, t, frac, dprod;
    float f_parx_tot, f_pary_tot, f_parz_tot;
    float f_perx_tot, f_pery_tot, f_perz_tot;
    float hydr_radius, gamma, mag;

    vec_s f_par, f_per;

    
    t    = step*params.dt;
    hydr_radius = params.hydr_radius;
    gamma = params.gamma;
    frac = t*params.freq/(2.0*PI); 
    n_mon = params.n_mon;

    sprintf( file_name,"%s%s%.2f", params.dir_name, "out_", frac );
    out_file_1 = fopen( file_name, "w" );


    //   for(j=0; j<params.n_fil;j++){   
    j=0;      
    for( i = 0; i < n_mon; i++ )
	{
	fprintf( out_file_1, "%.10e %.10e %.10e \n", 
		 r[i+j*n_mon].x, r[i+j*n_mon].y, r[i+j*n_mon].z );
	}
      //fprintf( out_file_1, "\n");
      //}
    fclose( out_file_1 );

} 


void print_force(vec_s *force, param_s par, int n_mon, char *filename)
{
   int i;
   static int num=0;
   FILE *f_ptr;
   char fname[100];
   char command[100];
   
  /*      sprintf(command,"mkdir -p %s%s",par.dir_name, "Force/"); */
/*        system(command); */
      
      sprintf(fname,"%s%s%s_%d",par.dir_name, "Force/", filename, num);

      f_ptr = fopen(fname, "w");
      for(i=0;i<=n_mon-1;i++){
         fprintf(f_ptr,"%d %.16g %.16g \n", i, force[i].x, force[i].y);
      }
      fclose(f_ptr);
   num++;
 
}



